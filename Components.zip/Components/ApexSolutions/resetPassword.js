import React, { useState, useEffect } from 'react';
import api from './api/axiosConfig'; // Your API configuration
import './style.css';  // Import your styles

function ResetPassword() {
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [token, setToken] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  // On component mount, get the token from URL
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const tokenFromUrl = urlParams.get('token');
    if (tokenFromUrl) {
      setToken(tokenFromUrl);
    } else {
      setErrorMessage('Invalid or missing token.');
    }
  }, []);

  // Handle input change for password fields
  const handlePasswordChange = (e) => {
    setPassword(e.target.value);
  };

  const handleConfirmPasswordChange = (e) => {
    setConfirmPassword(e.target.value);
  };

  const handleTokenChange = (e) => {
    setToken(e.target.value); // Handle token input by the user
  };

  // Submit the reset password form
  const handleSubmit = async (e) => {
    e.preventDefault();
    setErrorMessage('');
    setSuccessMessage('');

    if (password !== confirmPassword) {
      setErrorMessage('Passwords do not match.');
      return;
    }

    try {
      // Send token and new password to backend
      const response = await api.put('/auth/reset-password', {
        token: token, // Send token from the URL or input field
        userPassword: password, // Send new password
      });

      // Handle success response
      setSuccessMessage(response.data); // Expecting success message from backend
    } catch (error) {
      // Handle error
      if (error.response && error.response.status === 400) {
        setErrorMessage('Invalid token or password reset failed.');
      } else if (error.response && error.response.status === 401) {
        setErrorMessage('Unauthorized. Please log in and try again.');
      } else {
        setErrorMessage('An error occurred while resetting your password.');
      }
    }
  };

  return (
    <div className="fullPage">
      <div className="background">
        <div className="logo">
          <h1>ApexCareSolutions</h1>
        </div>  
        <div className="account">
          <div className="tagline"> 
            <div className="acc">Reset Password</div>
          </div>

      <p>Enter your new password below and provide the reset token.</p>
      <form onSubmit={handleSubmit} className="reset-password-form">
      <div className="form">
        {/* Token Input Field */}
        <div className="email">
          <label htmlFor="token">Token</label>
          <input
            type="text"
            id="token"
            name="token"
            value={token}
            onChange={handleTokenChange}
            placeholder="Enter reset token"
            required
          />
        </div>

        {/* New Password Input Field */}
        <div className="password">
          <label htmlFor="password">New Password</label>
          <input
            type="password"
            id="password"
            name="password"
            value={password}
            onChange={handlePasswordChange}
            placeholder="Enter new password"
            required
          />
        </div>

        {/* Confirm Password Input Field */}
        <div className="password">
          <label htmlFor="confirmPassword">Confirm Password</label>
          <input
            type="password"
            id="confirmPassword"
            name="confirmPassword"
            value={confirmPassword}
            onChange={handleConfirmPasswordChange}
            placeholder="Confirm new password"
            required
          />
        </div >

        <button className="btn2" type="submit">Reset Password</button>
      </div>
      </form>
    
      {/* Display success or error messages */}
      {successMessage && <div className="success-message">{successMessage}</div>}
      {errorMessage && <div className="error-message">{errorMessage}</div>}
    </div>
    </div>
    </div>
  );
}

export default ResetPassword;
