import React, { useState } from 'react';
import './style.css';
import { useNavigate } from 'react-router-dom';
import api from './api/axiosConfig.js';

function Register() {
    const [fName, setName] = useState('');
    const [surname, setSurname] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [day, setDay] = useState('');
    const [month, setMonth] = useState('');
    const [year, setYear] = useState('');
    const [gender, setGender] = useState('');
    const [role, setRole] = useState('');
    const [errors, setErrors] = useState({});

    const days = Array.from({ length: 31 }, (_, i) => i + 1);
    const months = [
          'January', 'February', 'March', 'April', 'May', 'June',
         'July', 'August', 'September', 'October', 'November', 'December'
    ];
    const years = Array.from({ length: 100 }, (_, i) => new Date().getFullYear() - i);
    const navigate = useNavigate();

    const validateForm = () => {
        const newErrors = {};
        const nameRegex = /^[a-zA-Z]{3,20}$/; // Alpha, 3-20 characters
        const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[A-Za-z\d@$!%*?&]{6,}$/; // At least one uppercase, one lowercase, one number, min 6 characters
        const emailRegex = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/;
        
        if (!fName) {
            newErrors.fName = "First Name is required";
        } else if (!nameRegex.test(fName)) {
            newErrors.fName = "First Name must be 3-20 characters long and contain only letters";
        }
        if (!surname) {
            newErrors.surname = "Surname is required";
        } else if (!nameRegex.test(surname)) {
            newErrors.surname = "Surname must be 3-20 characters long and contain only letters";
        }
        if (!email) {
            newErrors.email = "Email is required";
        } else if (!emailRegex.test(email)) {
            newErrors.email = "Invalid email address";
        }
        if (!password) {
            newErrors.password = "Password is required";
        } else if (!passwordRegex.test(password)) {
            newErrors.password = "Password must be at least 6 characters long, include an uppercase letter, a lowercase letter, and a number";
        }
        if (!day || !month || !year) {
            newErrors.dob = "Date of birth is required";
        } else {
            const dateOfBirth = new Date(`${year}-${month}-${day}`);
            if (isNaN(dateOfBirth.getTime())) {
                newErrors.dob = "Invalid date of birth";
            }
        }
        if (!gender) newErrors.gender = "Gender is required";
        if (!role) newErrors.role = "Role is required"; 
        return newErrors;
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        const validationErrors = validateForm();
        if (Object.keys(validationErrors).length > 0) {
            setErrors(validationErrors);
            return;
        }
        setErrors({});

        const dateOfBirthString = new Date(year, month - 1, day).toISOString().split('T')[0];

        try {
            await api.post('/auth/signup', {
                loginEntity: {
                    userEmail: email,
                    userPassword: password,
                    userRole: role
                },
                clientEntity: {
                    clientName: fName,
                    clientSurname: surname,
                    clientDOB: dateOfBirthString,
                    clientGender: gender
                }
            });
            alert('User registered successfully');
            navigate('/'); // Redirect to login page after successful registration
        } catch (error) {
            alert('Error creating user');
        }
    };

    return (
        <div className="fullPage">
            <div className="background">
                <div className="logo">
                    <h1>ApexCareSolutions</h1>
                </div>  
                <div className="account">
                    <div className="tagline">
                        <div className="acc">Create a new account</div>
                    </div>
                    <form onSubmit={handleSubmit}>
                        <div className="form">
                            <div className="name">
                                <div className="fName">
                                    <input type="text" placeholder="First Name" value={fName} onChange={(e) => setName(e.target.value)}/>
                                </div>
                                {errors.fName && <span className='error'>{errors.fName}</span>}
                                <div className="surname">
                                    <input type="text" placeholder="Surname" value={surname} onChange={(e) => setSurname(e.target.value)}/>
                                </div>
                                {errors.surname && <span className="error">{errors.surname}</span>}
                            </div>
                            <div className="email">
                                <input type="text" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)}/>
                            </div>  
                            {errors.email && <span className="error">{errors.email}</span>}
                            <div className="password">
                                <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)}/>
                                
                            </div>
                            {errors.password && <span className="error">{errors.password}</span>}
                            <div className="birthday">
                                <div className="dob">Date of birth<i className="fa-solid fa-circle-question"></i></div>
                            </div>
                            <div className="dmy">
                                <div className="d">  
                                    <select id="day" value={day} onChange={(e) => setDay(e.target.value)}>
                                        <option value="">Day</option>
                                        {days.map((d) => <option key={d} value={d}>{d}</option>)}
                                    </select>
                                </div>
                                <div className="m">
                                    <select id="month" value={month} onChange={(e) => setMonth(e.target.value)}>
                                        <option value="">Month</option>
                                        {months.map((m, index) => <option key={m} value={index + 1}>{m}</option>)}
                                    </select>
                                </div>
                                <div className="y">
                                    <select id="year" value={year} onChange={(e) => setYear(e.target.value)}>
                                        <option value="">Year</option>
                                        {years.map((y) => <option key={y} value={y}>{y}</option>)}
                                    </select>
                                </div>
                            </div>
                            {errors.dob && <span className="error">{errors.dob}</span>}
                            <div className="gender">
                                <div className="FM">Gender</div>
                                <div className="genderType">
                                    <div className="female">
                                        <label htmlFor="female">Female</label>
                                        <input type="radio" id="female" value="F" checked={gender === 'F'} onChange={(e) => setGender(e.target.value)}/>
                                    </div>
                                    <div className="male">
                                        <label htmlFor="male">Male</label>
                                        <input type="radio" id="male" value="M" checked={gender === 'M'} onChange={(e) => setGender(e.target.value)} />
                                    </div>
                                </div>
                                {errors.gender && <span className="error">{errors.gender}</span>}
                            </div>
                            <div className="role">
                                <div className="FM">Role</div>
                                <div className="roleType">
                                    <div className="client">
                                        <label htmlFor="client">Client</label>
                                        <input type="radio" id="client" value="Client" checked={role === 'Client'} onChange={(e) => setRole(e.target.value)}/>
                                    </div>
                                    <div className="technician">
                                        <label htmlFor="technician">Technician</label>
                                        <input type="radio" id="technician" value="Technician" checked={role === 'Technician'} onChange={(e) => setRole(e.target.value)} />
                                    </div>
                                </div> 
                                {errors.role && <span className="error">{errors.role}</span>}
                            </div>
                            <div className='signupBTN'>
                                <button className='btn' type="submit">Sign Up</button>
                            </div>
                            <div className="already">
                                <p className='log'>Already have an account? <br/><a href='/'>Login</a></p>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    );
}

export default Register;
