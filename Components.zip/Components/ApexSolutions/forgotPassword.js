import React, { useState } from 'react';
import api from './api/axiosConfig'; // Assuming this is where you set up your axios configuration
import './style.css'; // Import your styles if needed
import ResetPassword from './resetPassword.js';
import { useNavigate} from 'react-router-dom';

function ForgotPassword() {
  const [email, setEmail] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [resetDetails, setResetDetails] = useState(null); // New state to store the reset details

  const navigate = useNavigate();
  const handleChange = (e) => {
    setEmail(e.target.value);
  };

  // Submit form
  const handleSubmit = async (e) => {
    e.preventDefault();
    // Reset previous messages
    setErrorMessage('');
    setSuccessMessage('');
    setResetDetails(null); // Reset the reset details on each submit

    try {
      const response = await api.post('/auth/forgot-password', { 
        userEmail: email 
    });
      if (response.data) {
        setSuccessMessage('Password reset request successful.');
        
        
        // You can parse or directly use the response to get the details.
        
        const resetData = {
          toEmail: email, // Or use the response's email if it's returned
          subject: 'Password Reset Request',
          message: `Click the following link to reset your password:` + {ResetPassword},
          token: response.data.token, // Assuming the response contains a token
          resetLink: `http://localhost:8080/auth/reset_password?token=${response.data.token}` // Construct reset link
        
        };
        setResetDetails(resetData); // Store reset details
      }

      navigate('/reset_password')
    } catch (error) {
      // Handle error
      if (error.response && error.response.status === 404) {
        setErrorMessage('Email not found');
      } else {
        setErrorMessage('Error sending reset email. Please try again later.');
      }
    }
  };

  return (
    <div className="forgot-password-page">
      <h2>Forgot Password</h2>
      <p>Enter your email address to receive a password reset link.</p>
      
      <form onSubmit={handleSubmit} className="forgot-password-form">
        <div className="form-group">
          <label htmlFor="email">Email Address</label>
          <input
            type="email"
            id="email"
            name="email"
            value={email}
            onChange={handleChange}
            placeholder="Enter your email"
            required
          />
        </div>

        <button className="btn2" type="submit">Send Reset Link</button>
      </form>

      {/* Display success or error messages */}
      {successMessage && <div className="success-message">{successMessage}</div>}
      {errorMessage && <div className="error-message">{errorMessage}</div>}

      {/* Display the reset details (email, subject, message, and token) */}
      {resetDetails && (
        <div className="reset-details">
          <h3>Password Reset Details:</h3>
          <p><strong>To Email:</strong> {resetDetails.toEmail}</p>
          <p><strong>Subject:</strong> {resetDetails.subject}</p>
          <p><strong>Message:</strong> {resetDetails.message}</p>
          <p><strong>Token:</strong> {resetDetails.token}</p>
        </div>
      )}
    </div>
  );
}

export default ForgotPassword;
