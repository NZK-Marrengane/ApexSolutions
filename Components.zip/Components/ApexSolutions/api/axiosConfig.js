import axios from "axios";

export default axios.create({
    baseURL: "http://localhost:8080",
    headers: "Key = Content-Type | Value = application/json"
});