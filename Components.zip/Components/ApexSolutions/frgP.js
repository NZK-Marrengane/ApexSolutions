import React, { useState } from 'react';
//import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './style.css';
import api from './api/axiosConfig';


function FrgP() {

    
  const [email, setEmail] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [newPassword2, setNewPassword2] = useState('');
  const [errors, setErrors] = useState('');

    const validateForm = () => {
    const newErrors = {};
    const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[A-Za-z\d@$!%*?&]{6,}$/; // At least one uppercase, one lowercase, one number, min 6 characters
    const emailRegex = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/;

    if (!email) {
        newErrors.email = "Email is required";
    } else if (!emailRegex.test(email)) {
        newErrors.email = "Invalid email address";
    }
    if (!newPassword) {
        newErrors.newPassword = "Password is required";
    } else if (!passwordRegex.test(newPassword)) {
        newErrors.newPassword= "Password must be at least 6 characters long, include an uppercase letter, a lowercase letter, and a number";
    }
    if (!newPassword2) {
        newErrors.newPassword2 = "Confirm password ";
    } else if (newPassword!== newPassword2) {
        newErrors.newPassword2 = "Passwords do not match";
    }
    return newErrors;

  };





  const navigate = useNavigate();

  const handleSubmit = async (e) => {

    e.preventDefault();
    const validationErrors = validateForm();
    if (Object.keys(validationErrors).length > 0) {
        setErrors(validationErrors);
        return;
    }
    
    
    try {
       
      await api.get('auth/reset_password', { email });
      alert('Password has been reset');
      navigate('/');
    } catch (error) {
      alert('Error resetting password');
    }
  };






  return(
    <div className="fullPage">
    <div className="background">
    
        <div className="logo">
            <h1>ApexCareSolutions</h1>
        </div>  
        <div className="account">
                <div className="tagline">
                    <div className="acc">Reset Password</div>
                </div>
        
        <form action='' onSubmit={handleSubmit}>
            <div className='form'>
                <div className="email">
                    <input type="text" id="email" placeholder="Enter your email" value={email} onChange={(e) => setEmail(e.target.value)} />
                </div>
                {errors.email && <span className="error">{errors.email}</span>}
                <div className="newPassword">
                    <input type="password" id='password' placeholder="Enter new password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)}/>
                </div>
                {errors.newPassword && <span className="error">{errors.newPassword}</span>}
                <div className="newPassword2">
                    <input type="password" id='password' placeholder="Confirm new password" value={newPassword2} onChange={(e) => setNewPassword2(e.target.value)}/>
                </div>
                {errors.newPassword2 && <span className="error">{errors.newPassword2}</span>}
                <div className='resetBTN'>
                    <button className='btn2' type="submit">Reset Password</button>
                </div>
                <p className="already">
                <a href="./">Back to Login</a>
            </p>
            </div>
        </form>
    </div>
    </div>

</div>
      
  );


}

export default FrgP;
