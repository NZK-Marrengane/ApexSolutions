import React, { useState } from 'react';
import api from './api/axiosConfig';
import { useNavigate} from 'react-router-dom';
import './style.css';

function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('');
  const [errors, setErrors] = useState({});
  
  const validateForm = () => {
    const newErrors = {};
    const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[A-Za-z\d@$!%*?&]{6,}$/; // At least one uppercase, one lowercase, one number, min 6 characters
    const emailRegex = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/;

    if (!email) {
        newErrors.email = "Email is required";
    } else if (!emailRegex.test(email)) {
        newErrors.email = "Invalid email address";
    }
    if (!password) {
        newErrors.password = "Password is required";
    } else if (!passwordRegex.test(password)) {
        newErrors.password = "Password must be at least 6 characters long, include an uppercase letter, a lowercase letter, and a number";
    }

    return newErrors;
  };

  const navigate = useNavigate();
  const handleSubmit = async (e) => {
    e.preventDefault();
    const validationErrors = validateForm();
    if (Object.keys(validationErrors).length > 0) {
        setErrors(validationErrors);
        return;
    }
    try {
      await api.post('/auth/login', { 
        userEmail: email,
        userPassword: password,
        userRole: role 
      });
      alert('Login successful');
      navigate('/');
    } catch (error) {
      alert('Invalid credentials');
    }
  };

  return (
    <div className="fullPage">
      <div className="background">
        <div className="logo">
          <h1>ApexCareSolutions</h1>
        </div>  
        <div className="account">
          <div className="tagline"> 
            <div className="acc">Login</div>
          </div>
          <form action="" onSubmit={handleSubmit}>
            <div className="form">
              <div className="email">
                <input type="text" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)}/>
              </div>  
              {errors.email && <span className="error">{errors.email}</span>}
              <div className="password">
                <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)}/>
              </div>
              {errors.password && <span className="error">{errors.password}</span>}
              <div className="role">
                <div className="FM">Role</div>
                <div className="roleType">
                  <div className="client">
                    <label htmlFor="client">Client</label>
                    <input type="radio" name="role" id="client" value="Client" checked={role === 'Client'} onChange={(e) => setRole(e.target.value)}/>
                  </div>
                  <div className="technician">
                    <label htmlFor="technician">Technician</label>
                    <input type="radio" name="role" id="technician" value="Technician" checked={role === 'Technician'} onChange={(e) => setRole(e.target.value)} />
                  </div>
                </div>
                <br />
                {errors.role && <span className="error">{errors.role}</span>}
              </div>
              <div className="signupBTN">
                <button className="btn" type="submit">Login</button>
              </div>
              <div className="already">
                <p className='frgP'>Forgot Password? <br/><a href="/forgot_password">Reset Password</a></p>
                <p className='sign'>Don't have an account? <br/><a href="/signup">Sign Up</a></p>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}

export default Login;
